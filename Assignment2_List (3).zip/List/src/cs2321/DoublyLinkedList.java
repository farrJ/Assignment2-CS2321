package cs2321;
import java.util.Iterator;
import net.datastructures.Position;
import net.datastructures.PositionalList;


public class DoublyLinkedList<E> implements PositionalList<E> {
	

	/* 
	 * Node class which should contain element and pointers to previous and next nodes
	 */
	public static class Node<E> implements Position<E> {

		@Override
		public E getElement() {
			// TODO Auto-generated method stub
			return null;
		}
		
	}
	
	/*
	 *Element iterator will return one element at a time  
	 */
	private class ElementIterator implements Iterator<E> {
		
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public E next() {
			// TODO Auto-generated method stub
			return null;
		}
		
	}
	
	/*
	 * Position iterator will return one Position at a time  
	 */
	private class PositionIterator implements Iterator<Position<E>> {

		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public Position<E> next() {
			// TODO Auto-generated method stub
			return null;
		}
		
	}
	
	/*
	 * Position iterator will return one Position at a time  
	 */
	private class PositionIterable implements Iterable<Position<E>> {

		@Override
		public Iterator<Position<E>> iterator() {
			// TODO Auto-generated constructor stub
			return null;
		}
		
	}

	public DoublyLinkedList() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Position<E> first() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Position<E> last() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Position<E> before(Position<E> p) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Position<E> after(Position<E> p) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Position<E> addFirst(E e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Position<E> addLast(E e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Position<E> addBefore(Position<E> p, E e)
			throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Position<E> addAfter(Position<E> p, E e)
			throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E set(Position<E> p, E e) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E remove(Position<E> p) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}


	public E removeFirst() throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}
	
	public E removeLast() throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated constructor stub
		return null;
	}

	@Override
	public Iterable<Position<E>> positions() {
		// TODO Auto-generated constructor stub
		return null;
	}

	@Override
	public Object [] toArray() {
		// TODO Auto-generated method stub
		return null;
	}


}
